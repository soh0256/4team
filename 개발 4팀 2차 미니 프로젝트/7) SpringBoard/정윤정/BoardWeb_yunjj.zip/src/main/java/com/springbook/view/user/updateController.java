package com.springbook.view.user;

import java.io.IOException;
import java.sql.Connection;
import java.sql.SQLDataException;
import java.sql.SQLException;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.SessionAttributes;

import com.springbook.biz.common.JDBCUtil;
import com.springbook.biz.user.UserService;
import com.springbook.biz.user.UserVO;
import com.springbook.biz.user.impl.UserDAO;

@Controller
public class updateController {

		@Autowired
		private UserService userService;
	
		@RequestMapping(value="/changePwd.do", method=RequestMethod.GET)
		public String changeView() {
			return "changePwd.jsp";
		}
		
		@RequestMapping(value="/changePwd.do", method=RequestMethod.POST)
		public String changePassword(HttpServletRequest req, UserVO vo, UserDAO userDAO) {
		
			
			try {
				Connection conn = null;
				conn=JDBCUtil.getConnection();
				userDAO.updatePassword(vo, req);
				conn.commit();
				return "changeSuccess.jsp";
			
			} catch (Exception e) {
				e.getMessage();
				return "getBoardList.jsp";
			} 
			
		}
		
		
		
		

}
