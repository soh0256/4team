package com.springbook.view.user;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

import com.springbook.biz.user.UserVO;
import com.springbook.biz.user.impl.UserDAO;

@Controller
public class JoinController {

	@RequestMapping(value="/join.do", method=RequestMethod.GET)
	public String JoinView() {
		return "join.jsp";
	}
	
	@RequestMapping(value="/join.do", method=RequestMethod.POST)
	public String join(UserVO vo, UserDAO userDAO, HttpServletRequest req)throws Exception {
		vo.setId(req.getParameter("id"));
		vo.setName(req.getParameter("name"));
		vo.setPassword(req.getParameter("password"));
		vo.setRole("user");
		userDAO.joinUser(vo);
		
		
		return "joinSuccess.jsp";
	}
	
	
}
