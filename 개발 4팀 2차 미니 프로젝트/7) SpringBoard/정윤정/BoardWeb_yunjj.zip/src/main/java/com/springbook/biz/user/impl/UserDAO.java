package com.springbook.biz.user.impl;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;

import javax.servlet.http.HttpServletRequest;

import org.springframework.stereotype.Repository;

import com.springbook.biz.common.JDBCUtil;
import com.springbook.biz.user.UserVO;

// DAO(Data Access Object)
@Repository("userDAO")
public class UserDAO {
	// JDBC ���� ����
	private Connection conn = null;
	private PreparedStatement stmt = null;
	private ResultSet rs = null;
	// SQL ���ɾ��
	private final String USER_JOIN = "insert into users values(?,?,?,?)";
	private final String USER_GET = "select * from users where id=? and password=?";
	private final String CHANGE_PWD = "update users set name = ?, password = ? where id = ?";
	private final String SELECT_PWD = "select * from users where password = ?";
	// CRUD ����� �޼ҵ� ����
	//ȸ������
	public void joinUser(UserVO vo) throws Exception {
		UserVO user=null;
		conn=JDBCUtil.getConnection();
		stmt=conn.prepareStatement(USER_JOIN);
		stmt.setString(1, vo.getId());
		stmt.setString(2, vo.getPassword());
		stmt.setString(3, vo.getName());
		stmt.setString(4, vo.getRole());
		stmt.execute();
		
	}
	
	
	// ȸ�� ��������
	public UserVO getUser(UserVO vo) {
		UserVO user = null;
		try {
			System.out.println("===> JDBC�� getUser() ��� ó��");
			conn = JDBCUtil.getConnection();
			stmt = conn.prepareStatement(USER_GET);
			stmt.setString(1, vo.getId());
			stmt.setString(2, vo.getPassword());
			rs = stmt.executeQuery();
			if (rs.next()) {
				user = new UserVO();
				user.setId(rs.getString("ID"));
				user.setPassword(rs.getString("PASSWORD"));
				user.setName(rs.getString("NAME"));
				user.setRole(rs.getString("ROLE"));
			}
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			JDBCUtil.close(rs, stmt, conn);
		}
		return user;
	}
	
	//ȸ�� �ҷ����� 
	public UserVO selectByPwd(Connection conn, String password) {
		PreparedStatement stmt  = null;
		ResultSet rs = null;
		UserVO vo = null;
		try {
		stmt = conn.prepareStatement(SELECT_PWD);
		stmt.setString(1, password);
		rs = stmt.executeQuery();
		if(rs.next()) {
		vo = new UserVO(rs.getString("id"), rs.getString("password"), rs.getString("name"));
		}
		return vo;
		} catch(Exception e) {
			e.printStackTrace();
			return null;
		}
	}
	
	//��й�ȣ ����
	public void updatePassword(UserVO vo, HttpServletRequest req) throws Exception{
		UserDAO userDAO = new UserDAO();
		System.out.println("===> JDBC�� update() ��� ó��");
	try {	
		conn = JDBCUtil.getConnection();
		String newPwd = req.getParameter("newPwd");
		System.out.println(newPwd + "," + vo.getName() + "," + vo.getId());
		
		vo = userDAO.selectByPwd(conn, req.getParameter("password"));
		vo.changePassword(newPwd);
		stmt = conn.prepareStatement(CHANGE_PWD);
		stmt.setString(1, vo.getName());
		stmt.setString(2, newPwd);
		stmt.setString(3, vo.getId());
		stmt.executeUpdate();
		
		}catch (Exception e) {
			e.printStackTrace();
		} finally {
			JDBCUtil.close(stmt, conn);
		}
	}
}