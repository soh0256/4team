package polymorphism;

public interface Speaker {

	void volumUp();

	void volumDown();

}