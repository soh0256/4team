package com.springbook.biz;

public class Test {

	public static void main(String[] args) {
		System.out.println("hello Java~");
	}

}
