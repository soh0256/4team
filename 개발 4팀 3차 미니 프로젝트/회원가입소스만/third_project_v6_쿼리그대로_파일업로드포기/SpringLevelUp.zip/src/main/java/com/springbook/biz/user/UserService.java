package com.springbook.biz.user;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;

import org.springframework.web.bind.annotation.ModelAttribute;

import com.springbook.biz.user.impl.UserDAO;

public interface UserService {
	// CRUD ����� �޼ҵ� ����
	// ȸ�� ���
	public UserVO getUser(String id);
	
	public void insertUser(UserVO vo);
	
	public	void updateUser(UserVO vo);
	
	public void deleteUser(UserVO vo);
	

}
