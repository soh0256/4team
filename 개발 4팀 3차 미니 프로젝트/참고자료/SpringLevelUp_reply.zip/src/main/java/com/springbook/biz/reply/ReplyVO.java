package com.springbook.biz.reply;

import lombok.Getter;
import lombok.Setter;

@Getter@Setter
public class ReplyVO {
private String boardNo;
private String Id;
private String userReplyno;
private String userReply;
private String replyDate;
}
